import type { NextConfig } from "next";

/**
 * إعدادات Next.js لـ GitHub Pages
 *
 * - output: "export" → يبني نسخة Static (HTML/CSS/JS فقط)
 * - images.unoptimized → GitHub Pages ما يدعم Next.js Image Optimization
 * - basePath → يُحدد تلقائياً من GitHub Actions عبر NEXT_BASE_PATH
 *              لو تشغّل محلياً، الافتراضي "/images-to-pdf"
 */

const nextConfig: NextConfig = {
  output: "export",
  // basePath: يُقرأ من متغير البيئة (يضبطه GitHub Actions تلقائياً)
  basePath: process.env.NEXT_BASE_PATH || "/images-to-pdf",
  // GitHub Pages ما يدعم تحسين الصور
  images: {
    unoptimized: true,
  },
  // تجاهل أخطاء TypeScript أثناء البناء
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // إضافة trailing slash عشان GitHub Pages يشتغل صح
  trailingSlash: true,
};

export default nextConfig;
