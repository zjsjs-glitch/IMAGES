# 📷 صور إلى PDF — محوّل آمن (نسخة GitHub Pages)

تطبيق ويب يحوّل صورك إلى ملف PDF **بالكامل داخل متصفحك**، بدون رفع أي صورة لأي خادم.

> 🔒 صورك ما تغادر جهازك إطلاقاً — كل المعالجة تتم محلياً في المتصفح.

## 🚀 النشر على GitHub Pages — خطوة بخطوة

### المتطلبات
- حساب GitHub (مجاني): [github.com](https://github.com)

---

### 1️⃣ أنشئ مستودع جديد على GitHub

1. روح لـ **[github.com/new](https://github.com/new)**
2. اسم المستودع: **`images-to-pdf`** (مهم! استخدم هذا الاسم بالضبط)
   - ❌ لو سمّيت المستودع باسم ثاني، لازم تعدّل ملف `next.config.ts` وتغيّر `basePath`
3. اختر **Public** (عام)
4. ✅ علّم خيار **"Add a README file"**
5. اضغط **"Create repository"**

---

### 2️⃣ ارفع ملفات المشروع

#### الطريقة الأسهل (Drag & Drop على GitHub):

1. حمّل ملف `images-to-pdf-github.zip` وفك الضغط
2. في صفحة مستودع GitHub، اضغط **"uploading an existing file"**
3. **اسحب كل محتويات مجلد `deploy-github`** (ما عدا المجلد نفسه) إلى المنطقة
   - ملفات مثل: `package.json`, `next.config.ts`, `src/`, `public/`, `.github/`, إلخ
4. اكتب رسالة commit: `Initial commit`
5. اضغط **"Commit changes"**

#### أو بالطرفية (لو تعرف git):

```bash
git clone https://github.com/USERNAME/images-to-pdf.git
cd images-to-pdf
# انسخ كل ملفات deploy-github هنا
git add .
git commit -m "Initial commit"
git push origin main
```

---

### 3️⃣ فعّل GitHub Pages

1. في صفحة المستودع، اضغط **"Settings"** (تبويب فوق)
2. في القائمة الجانبية اليسرى، اضغط **"Pages"** (تحت قسم Code and automation)
3. تحت **"Build and deployment"**:
   - **Source:** اختر **"GitHub Actions"** (مهم! مو "Deploy from a branch")
4. ✅ خلصت! ما تحتاج تسوي شي ثاني.

---

### 4️⃣ انتظر النشر (2-3 دقائق)

1. اذهب لتبويب **"Actions"** في المستودع
2. بتشوف workflow اسمه **"Deploy to GitHub Pages"** شغّال
3. ⏳ انتظر ما يخلص (يطلع علامة خضراء ✅)
4. ارجع لـ **Settings ← Pages** ← بتلقى الرابط
5. ✅ **رابط موقعك:** `https://USERNAME.github.io/images-to-pdf/`

---

## 🔄 لو حابب تغير اسم المستودع

لو تبي اسم ثاني (مو `images-to-pdf`):

1. افتح ملف `next.config.ts`
2. غيّر السطر:
   ```ts
   basePath: process.env.NEXT_BASE_PATH || "/images-to-pdf",
   ```
3. استبدل `images-to-pdf` باسم مستودعك الجديد
4. ارفع التعديل على GitHub → راح يُعاد النشر تلقائياً

---

## ✨ المميزات

- 🔒 **خصوصية كاملة** — لا يوجد رفع، لا تتبّع، لا قاعدة بيانات
- 📱 **مصمم للهاتف** — واجهة عربية (RTL) بأزرار كبيرة
- 🔄 **إعادة ترتيب بالسحب** — اسحب الصور لترتيب صفحات PDF
- ⚙️ **إعدادات قابلة للتخصيص**:
  - حجم الصفحة: مطابقة / A4 / Letter
  - الهامش
  - التدوير
  - تدرية رمادية
  - جودة الصورة
  - أقصى أبعاد للصورة
- 👀 **معاينة فورية** للـ PDF داخل الصفحة
- 📤 **تحميل + مشاركة + فتح**
- 📷 **التقاط مباشر من الكاميرا**

## 💰 خطة GitHub Pages المجانية

| الميزة | القيمة |
|--------|--------|
| الباندويث الشهري | 100 GB |
| عدد المواقع | غير محدود |
| الـ Builds | غير محدود (عبر GitHub Actions) |
| الاستخدام التجاري | ✅ مسموح |
| شهادة HTTPS | تلقائية |
| نطاق فرعي | `USERNAME.github.io/REPO-NAME` |
| نطاق مخصص | ✅ مجاني (لو عندك domain) |

## 🛠️ التقنيات

- **Next.js 16** (App Router) — مع `output: 'export'` للتصدير الثابت
- **TypeScript 5**
- **Tailwind CSS 4** + **shadcn/ui**
- **pdf-lib** — لإنشاء PDF داخل المتصفح
- **@dnd-kit/sortable** — لإعادة الترتيب بالسحب
- **GitHub Actions** — للنشر التلقائي

## 💻 التشغيل محلياً (للتطوير)

```bash
# ثبّت الاعتماديات
npm install

# شغّل خادم التطوير
npm run dev
# افتح: http://localhost:3000

# بناء نسخة Static (تطلع في مجلد out/)
npm run build
```

## 📁 هيكل المشروع

```
deploy-github/
├── .github/
│   └── workflows/
│       └── deploy.yml         # ⭐ GitHub Actions للنشر التلقائي
├── src/
│   ├── app/
│   │   ├── layout.tsx         # التخطيط الرئيسي (RTL عربي)
│   │   ├── page.tsx           # الصفحة الرئيسية
│   │   └── globals.css        # الأنماط العامة
│   ├── components/ui/         # مكوّنات shadcn/ui
│   ├── hooks/                 # React hooks
│   └── lib/
│       ├── pdf-utils.ts       # ⭐ منطق إنشاء PDF
│       └── utils.ts           # دوال مساعدة
├── public/                    # ملفات عامة
├── next.config.ts             # ⭐ إعدادات Next.js (مع basePath)
├── package.json               # الاعتماديات
├── tsconfig.json
├── tailwind.config.ts
├── postcss.config.mjs
├── components.json
├── eslint.config.mjs
└── README.md                  # هذا الملف
```

## 🔐 كيف تعمل الخصوصية؟

1. **اختيار الصور:** `URL.createObjectURL()` — رابط محلي (ما يرفع)
2. **معالجة الصور:** `<canvas>` لإعادة الترميز محلياً
3. **إنشاء PDF:** `pdf-lib` لتجميع الصور داخل المتصفح
4. **التحميل:** Blob URL → تحميل مباشر لجهازك

**لا يوجد أي طلب شبكة يحمل بيانات صورك.** تقدر تتحقق من Developer Tools ← Network.

## ❓ استكشاف الأخطاء

### المشكلة: الموقع يطلع صفحة بيضاء / 404
**السبب:** غالباً المشكلة في `basePath`

**الحل:**
- لو رابط موقعك: `https://USERNAME.github.io/images-to-pdf/`
  → `basePath` لازم يكون `/images-to-pdf` ✅ (الافتراضي)
- لو رابط موقعك: `https://USERNAME.github.io/` (لو اسم المستودع = اسم المستخدم)
  → `basePath` لازم يكون `""` (فاضي)

عدّل ملف `next.config.ts` وارفع التعديل.

### المشكلة: GitHub Actions فشل
**الحل:**
1. اذهب لتبويب **Actions** في المستودع
2. اضغط على الـ workflow الفاشل
3. شوف الخطأ بالتفصيل
4. لو في مشكلة مع `npm install`، جرب:
   ```bash
   npm install --legacy-peer-deps
   ```

### المشكلة: الكاميرا ما تشتغل على الموقع
**السبب:** GitHub Pages يعطيك HTTPS تلقائياً، فالكاميرا تشتغل ✅
لو ما تشتغل، تأكد إنك تفتح بـ `https://` مو `http://`

### المشكلة: الصور ما تطلع في PDF
**الحل:** تأكد إن متصفحك يدعم `<canvas>` و `URL.createObjectURL()` (كل المتصفحات الحديثة تدعمها)

---

صُنع بـ ❤️ باستخدام Next.js + pdf-lib + GitHub Pages
