"use client";

import * as React from "react";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  TouchSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import {
  ImagePlus,
  Trash2,
  FileDown,
  Download,
  ShieldCheck,
  Lock,
  Loader2,
  X,
  RotateCw,
  Settings2,
  Images,
  Github,
  Smartphone,
  Layers,
  Eye,
  CheckCircle2,
  ExternalLink,
  FileText,
  Share2,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

import {
  buildPdf,
  formatBytes,
  loadImageItem,
  PAGE_SIZES,
  triggerDownload,
  type BuildPdfOptions,
  type ImageItem,
  type PageSizeKey,
} from "@/lib/pdf-utils";

// ──────────────────────────────────────────────────────────────────────────────
// Generated PDF result
// ──────────────────────────────────────────────────────────────────────────────
interface PdfResult {
  bytes: Uint8Array;
  url: string;
  filename: string;
  size: number;
  pageCount: number;
  createdAt: number;
}

// ──────────────────────────────────────────────────────────────────────────────
// Sortable image card
// ──────────────────────────────────────────────────────────────────────────────
function SortableImage({
  item,
  index,
  onRemove,
  onPreview,
}: {
  item: ImageItem;
  index: number;
  onRemove: (id: string) => void;
  onPreview: (item: ImageItem) => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } =
    useSortable({ id: item.id });

  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 50 : undefined,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(
        "group relative flex items-center gap-3 rounded-xl border bg-card p-2.5 shadow-xs transition-shadow",
        isDragging && "shadow-lg ring-2 ring-primary/40",
      )}
    >
      {/* Drag handle */}
      <button
        type="button"
        {...attributes}
        {...listeners}
        className="flex h-14 w-9 shrink-0 cursor-grab touch-none items-center justify-center rounded-md text-muted-foreground hover:bg-accent active:cursor-grabbing"
        aria-label="اسحب لإعادة الترتيب"
      >
        <span className="text-lg leading-none">⋮⋮</span>
      </button>

      {/* Thumbnail */}
      <button
        type="button"
        onClick={() => onPreview(item)}
        className="relative h-16 w-16 shrink-0 overflow-hidden rounded-lg border bg-muted"
        aria-label="معاينة الصورة"
      >
        <img
          src={item.url}
          alt={item.name}
          className="h-full w-full object-cover"
          draggable={false}
        />
      </button>

      {/* Info */}
      <div className="flex min-w-0 flex-1 flex-col">
        <span className="truncate text-sm font-medium" title={item.name}>
          {item.name}
        </span>
        <span className="text-xs text-muted-foreground" dir="ltr">
          {item.width}×{item.height} • {formatBytes(item.size)}
        </span>
        <Badge variant="secondary" className="mt-1 w-fit text-[10px]">
          صفحة {index + 1}
        </Badge>
      </div>

      {/* Remove */}
      <Button
        type="button"
        size="icon"
        variant="ghost"
        className="h-9 w-9 shrink-0 text-muted-foreground hover:text-destructive"
        onClick={() => onRemove(item.id)}
        aria-label="حذف الصورة"
      >
        <Trash2 className="h-4 w-4" />
      </Button>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────────────────────
// Main page
// ──────────────────────────────────────────────────────────────────────────────
export default function Home() {
  const { toast } = useToast();
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const cameraInputRef = React.useRef<HTMLInputElement>(null);

  const [images, setImages] = React.useState<ImageItem[]>([]);
  const [isProcessing, setIsProcessing] = React.useState(false);
  const [isLoadingImages, setIsLoadingImages] = React.useState(false);

  // Settings
  const [pageSize, setPageSize] = React.useState<PageSizeKey>("fit");
  const [margin, setMargin] = React.useState(24);
  const [rotate, setRotate] = React.useState<0 | 90 | 180 | 270>(0);
  const [grayscale, setGrayscale] = React.useState(false);
  const [quality, setQuality] = React.useState(0.85);
  const [maxDimension, setMaxDimension] = React.useState(2000);
  const [fileName, setFileName] = React.useState("images-to-pdf");

  // Preview modal
  const [previewItem, setPreviewItem] = React.useState<ImageItem | null>(null);
  const [settingsOpen, setSettingsOpen] = React.useState(false);

  // Generated PDF result
  const [result, setResult] = React.useState<PdfResult | null>(null);
  const resultUrlRef = React.useRef<string | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(TouchSensor, {
      activationConstraint: { delay: 180, tolerance: 6 },
    }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  // Cleanup object URLs on unmount / removal
  const urlsRef = React.useRef<Set<string>>(new Set());
  React.useEffect(() => {
    const current = new Set(images.map((i) => i.url));
    // Revoke any URL that's no longer in the list
    urlsRef.current.forEach((url) => {
      if (!current.has(url)) {
        URL.revokeObjectURL(url);
        urlsRef.current.delete(url);
      }
    });
    // Track current
    urlsRef.current = current;
  }, [images]);

  React.useEffect(() => {
    return () => {
      urlsRef.current.forEach((url) => URL.revokeObjectURL(url));
      urlsRef.current.clear();
      if (resultUrlRef.current) {
        URL.revokeObjectURL(resultUrlRef.current);
        resultUrlRef.current = null;
      }
    };
  }, []);

  const handleFiles = React.useCallback(
    async (files: FileList | null) => {
      if (!files || files.length === 0) return;
      const fileArr = Array.from(files).filter((f) => f.type.startsWith("image/"));
      if (fileArr.length === 0) {
        toast({
          title: "لا توجد صور",
          description: "الرجاء اختيار ملفات صور صالحة.",
          variant: "destructive",
        });
        return;
      }
      setIsLoadingImages(true);
      try {
        const items: ImageItem[] = [];
        for (const f of fileArr) {
          try {
            const item = await loadImageItem(f);
            items.push(item);
          } catch (err) {
            console.error("Failed to load image", f.name, err);
          }
        }
        if (items.length === 0) {
          throw new Error("تعذّر قراءة أي صورة من الملفات المختارة.");
        }
        setImages((prev) => [...prev, ...items]);
        toast({
          title: "تمت إضافة الصور",
          description: `أُضيفت ${items.length} صورة بنجاح.`,
        });
      } catch (e) {
        toast({
          title: "خطأ في تحميل الصور",
          description: e instanceof Error ? e.message : "حاول مرة أخرى.",
          variant: "destructive",
        });
      } finally {
        setIsLoadingImages(false);
      }
    },
    [toast],
  );

  const handleDrop = React.useCallback(
    (e: React.DragEvent<HTMLLabelElement>) => {
      e.preventDefault();
      e.stopPropagation();
      handleFiles(e.dataTransfer.files);
    },
    [handleFiles],
  );

  const removeImage = React.useCallback((id: string) => {
    setImages((prev) => prev.filter((i) => i.id !== id));
  }, []);

  const clearAll = React.useCallback(() => {
    setImages([]);
  }, []);

  const handleDragEnd = React.useCallback(
    (event: DragEndEvent) => {
      const { active, over } = event;
      if (!over || active.id === over.id) return;
      setImages((items) => {
        const oldIndex = items.findIndex((i) => i.id === active.id);
        const newIndex = items.findIndex((i) => i.id === over.id);
        if (oldIndex < 0 || newIndex < 0) return items;
        return arrayMove(items, oldIndex, newIndex);
      });
    },
    [],
  );

  const handleGenerate = React.useCallback(async () => {
    if (images.length === 0) {
      toast({
        title: "لا توجد صور",
        description: "أضف صورة واحدة على الأقل قبل التحويل.",
        variant: "destructive",
      });
      return;
    }
    setIsProcessing(true);
    try {
      // Yield to UI so the spinner can paint
      await new Promise((r) => setTimeout(r, 30));
      const opts: BuildPdfOptions = {
        pageSize,
        margin,
        rotate,
        grayscale,
        quality,
        maxDimension,
        includeMetadata: true,
      };
      const bytes = await buildPdf(images, opts);
      const safeName = (fileName || "images-to-pdf")
        .trim()
        .replace(/\.pdf$/i, "");
      const filename = `${safeName}.pdf`;

      // Build a blob URL for preview + later download
      const blob = new Blob([bytes as BlobPart], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);

      // Revoke previous result URL if any
      if (resultUrlRef.current) {
        URL.revokeObjectURL(resultUrlRef.current);
      }
      resultUrlRef.current = url;

      setResult({
        bytes,
        url,
        filename,
        size: bytes.byteLength,
        pageCount: images.length,
        createdAt: Date.now(),
      });

      toast({
        title: "تم إنشاء PDF ✓",
        description: `${images.length} صفحة • ${formatBytes(
          bytes.byteLength,
        )} — جاهز للتحميل`,
      });
    } catch (e) {
      toast({
        title: "فشل إنشاء PDF",
        description: e instanceof Error ? e.message : "حاول مرة أخرى.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  }, [
    images,
    pageSize,
    margin,
    rotate,
    grayscale,
    quality,
    maxDimension,
    fileName,
    toast,
  ]);

  const handleDownload = React.useCallback(() => {
    if (!result) return;
    triggerDownload(result.bytes, result.filename);
    toast({
      title: "جارٍ التحميل...",
      description: `سيتم حفظ ${result.filename} على جهازك.`,
    });
  }, [result, toast]);

  const handleOpenInNewTab = React.useCallback(() => {
    if (!result) return;
    window.open(result.url, "_blank", "noopener,noreferrer");
  }, [result]);

  const handleShare = React.useCallback(async () => {
    if (!result) return;
    // Try Web Share API with files (works on mobile browsers)
    try {
      const blob = new Blob([result.bytes as BlobPart], {
        type: "application/pdf",
      });
      const file = new File([blob], result.filename, {
        type: "application/pdf",
      });
      const nav = navigator as Navigator & {
        canShare?: (data: ShareData) => boolean;
        share?: (data: ShareData) => Promise<void>;
      };
      if (nav.canShare && nav.canShare({ files: [file] }) && nav.share) {
        await nav.share({
          files: [file],
          title: result.filename,
          text: "ملف PDF أُنشئ محلياً",
        });
        return;
      }
    } catch {
      // fall through to opening in new tab
    }
    // Fallback: open in new tab
    window.open(result.url, "_blank", "noopener,noreferrer");
  }, [result]);

  const handleDiscardResult = React.useCallback(() => {
    if (resultUrlRef.current) {
      URL.revokeObjectURL(resultUrlRef.current);
      resultUrlRef.current = null;
    }
    setResult(null);
  }, []);

  const totalSize = images.reduce((acc, i) => acc + i.size, 0);

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-emerald-50/40 via-background to-background">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b bg-background/85 backdrop-blur-md">
        <div className="mx-auto flex w-full max-w-3xl items-center gap-3 px-4 py-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-600 text-white shadow-sm">
            <FileDown className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <h1 className="text-base font-bold leading-tight">صور → PDF</h1>
            <p className="text-[11px] text-muted-foreground">
              محوّل آمن • المعالجة داخل جهازك
            </p>
          </div>
          <Sheet open={settingsOpen} onOpenChange={setSettingsOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" aria-label="إعدادات">
                <Settings2 className="h-4 w-4" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[90vw] max-w-md overflow-y-auto">
              <SheetHeader>
                <SheetTitle>إعدادات PDF</SheetTitle>
                <SheetDescription>
                  اضبط خيارات إنشاء ملف PDF. كل الخيارات مطبّقة محلياً.
                </SheetDescription>
              </SheetHeader>
              <SettingsPanel
                pageSize={pageSize}
                setPageSize={setPageSize}
                margin={margin}
                setMargin={setMargin}
                rotate={rotate}
                setRotate={setRotate}
                grayscale={grayscale}
                setGrayscale={setGrayscale}
                quality={quality}
                setQuality={setQuality}
                maxDimension={maxDimension}
                setMaxDimension={setMaxDimension}
              />
            </SheetContent>
          </Sheet>
        </div>
      </header>

      {/* Main */}
      <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col gap-4 px-4 py-5">
        {/* Privacy banner */}
        <Card className="border-emerald-200 bg-emerald-50/70 dark:border-emerald-900/50 dark:bg-emerald-950/20">
          <CardContent className="flex items-start gap-3 p-3.5">
            <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-emerald-600 text-white">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div className="flex-1 text-[13px] leading-relaxed">
              <p className="font-semibold text-emerald-900 dark:text-emerald-100">
                خصوصية كاملة — صورك لا تغادر جهازك
              </p>
              <p className="mt-0.5 text-emerald-800/80 dark:text-emerald-200/70">
                كل المعالجة تتم داخل متصفحك. لا يتم رفع أي صورة لأي خادم، ولا نحتفظ بأي بيانات.
              </p>
            </div>
            <Lock className="h-4 w-4 shrink-0 text-emerald-700 dark:text-emerald-300" />
          </CardContent>
        </Card>

        {/* Upload zone */}
        <label
          htmlFor="file-input"
          onDragOver={(e) => {
            e.preventDefault();
            e.currentTarget.classList.add("ring-2", "ring-emerald-500", "bg-emerald-50/50");
          }}
          onDragLeave={(e) => {
            e.currentTarget.classList.remove("ring-2", "ring-emerald-500", "bg-emerald-50/50");
          }}
          onDrop={handleDrop}
          className={cn(
            "flex cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-emerald-300 bg-emerald-50/30 p-7 text-center transition-colors hover:bg-emerald-50/60",
            isLoadingImages && "pointer-events-none opacity-70",
          )}
        >
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-100 text-emerald-700">
            {isLoadingImages ? (
              <Loader2 className="h-6 w-6 animate-spin" />
            ) : (
              <ImagePlus className="h-6 w-6" />
            )}
          </div>
          <div>
            <p className="text-sm font-semibold">
              {isLoadingImages ? "جارٍ تحميل الصور..." : "اضغط لاختيار صور"}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              أو اسحب وأفلت الصور هنا • PNG, JPG, WEBP
            </p>
          </div>
          <input
            id="file-input"
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={(e) => {
              handleFiles(e.target.files);
              e.target.value = "";
            }}
          />
        </label>

        {/* Quick action buttons */}
        <div className="grid grid-cols-2 gap-2.5">
          <Button
            type="button"
            variant="outline"
            className="h-12 gap-2"
            onClick={() => fileInputRef.current?.click()}
            disabled={isLoadingImages}
          >
            <Images className="h-4 w-4" />
            <span className="text-sm">من المعرض</span>
          </Button>
          <Button
            type="button"
            variant="outline"
            className="h-12 gap-2"
            onClick={() => cameraInputRef.current?.click()}
            disabled={isLoadingImages}
          >
            <Smartphone className="h-4 w-4" />
            <span className="text-sm">التقاط صورة</span>
          </Button>
          <input
            ref={cameraInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={(e) => {
              handleFiles(e.target.files);
              e.target.value = "";
            }}
          />
        </div>

        {/* Images list */}
        {images.length > 0 ? (
          <div className="mt-2 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-semibold">
                  الصور ({images.length})
                </h2>
                <Badge variant="secondary" className="text-[10px]" dir="ltr">
                  {formatBytes(totalSize)}
                </Badge>
              </div>
              <Button
                type="button"
                size="sm"
                variant="ghost"
                className="h-8 gap-1 text-xs text-muted-foreground hover:text-destructive"
                onClick={clearAll}
              >
                <Trash2 className="h-3.5 w-3.5" />
                مسح الكل
              </Button>
            </div>

            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={handleDragEnd}
            >
              <SortableContext
                items={images.map((i) => i.id)}
                strategy={verticalListSortingStrategy}
              >
                <div className="flex flex-col gap-2.5">
                  {images.map((item, idx) => (
                    <SortableImage
                      key={item.id}
                      item={item}
                      index={idx}
                      onRemove={removeImage}
                      onPreview={setPreviewItem}
                    />
                  ))}
                </div>
              </SortableContext>
            </DndContext>

            <p className="mt-1 flex items-center gap-1.5 text-[11px] text-muted-foreground">
              <Layers className="h-3.5 w-3.5" />
              ترتيب القائمة = ترتيب الصفحات في PDF. اسحب أي صورة لإعادة ترتيبها.
            </p>
          </div>
        ) : (
          <div className="mt-2 flex flex-col items-center gap-2 py-6 text-center text-muted-foreground">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
              <Images className="h-5 w-5" />
            </div>
            <p className="text-sm">لم تتم إضافة صور بعد</p>
            <p className="text-xs">اختر صوراً من المعرض أو التقطها بالكاميرا لبدء التحويل.</p>
          </div>
        )}

        <Separator className="my-2" />

        {/* File name + generate */}
        <div className="flex flex-col gap-3">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="filename" className="text-xs text-muted-foreground">
              اسم ملف PDF
            </Label>
            <div className="flex items-center gap-2">
              <Input
                id="filename"
                value={fileName}
                onChange={(e) => setFileName(e.target.value)}
                placeholder="images-to-pdf"
                className="flex-1"
                dir="ltr"
              />
              <span className="text-sm text-muted-foreground">.pdf</span>
            </div>
          </div>

          <Button
            type="button"
            size="lg"
            onClick={handleGenerate}
            disabled={isProcessing || images.length === 0}
            className="h-14 w-full gap-2 bg-emerald-600 text-base font-semibold text-white shadow-md hover:bg-emerald-700"
          >
            {isProcessing ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                جارٍ إنشاء PDF...
              </>
            ) : (
              <>
                <FileDown className="h-5 w-5" />
                تحويل إلى PDF ({images.length})
              </>
            )}
          </Button>
        </div>

        {/* Result card — appears after PDF generation */}
        {result && (
          <Card className="overflow-hidden border-emerald-300 bg-emerald-50/60 shadow-md dark:border-emerald-800/60 dark:bg-emerald-950/30">
            <CardContent className="p-0">
              {/* Success header */}
              <div className="flex items-center gap-3 border-b border-emerald-200/60 bg-emerald-100/50 p-4 dark:border-emerald-900/50 dark:bg-emerald-900/20">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-emerald-600 text-white shadow-sm">
                  <CheckCircle2 className="h-6 w-6" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-bold text-emerald-900 dark:text-emerald-100">
                    تم إنشاء ملف PDF بنجاح
                  </p>
                  <p className="text-xs text-emerald-800/80 dark:text-emerald-200/70">
                    جاهز للتحميل — الملف محفوظ مؤقتاً في ذاكرة المتصفح فقط
                  </p>
                </div>
                <Button
                  type="button"
                  size="icon"
                  variant="ghost"
                  className="h-8 w-8 shrink-0 text-emerald-800/60 hover:bg-emerald-200/50 hover:text-emerald-900 dark:text-emerald-200/60"
                  onClick={handleDiscardResult}
                  aria-label="إغلاق"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              {/* File info */}
              <div className="flex items-center gap-3 p-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-400">
                  <FileText className="h-6 w-6" />
                </div>
                <div className="min-w-0 flex-1">
                  <p
                    className="truncate text-sm font-semibold"
                    title={result.filename}
                    dir="ltr"
                  >
                    {result.filename}
                  </p>
                  <p className="text-xs text-muted-foreground" dir="ltr">
                    {result.pageCount} صفحة • {formatBytes(result.size)}
                  </p>
                </div>
              </div>

              {/* PDF preview (iframe) */}
              <div className="border-y border-emerald-200/60 bg-white/50 dark:border-emerald-900/50 dark:bg-zinc-950/30">
                <iframe
                  src={result.url}
                  title="معاينة PDF"
                  className="h-[320px] w-full"
                  style={{ border: "none" }}
                />
              </div>

              {/* Action buttons */}
              <div className="grid grid-cols-2 gap-2 p-4 sm:grid-cols-4">
                <Button
                  type="button"
                  size="lg"
                  onClick={handleDownload}
                  className="h-12 gap-2 bg-emerald-600 text-sm font-semibold text-white shadow-sm hover:bg-emerald-700"
                >
                  <Download className="h-5 w-5" />
                  تحميل
                </Button>
                <Button
                  type="button"
                  size="lg"
                  variant="outline"
                  onClick={handleShare}
                  className="h-12 gap-2 text-sm font-semibold"
                >
                  <Share2 className="h-4 w-4" />
                  مشاركة
                </Button>
                <Button
                  type="button"
                  size="lg"
                  variant="outline"
                  onClick={handleOpenInNewTab}
                  className="h-12 gap-2 text-sm font-semibold"
                >
                  <ExternalLink className="h-4 w-4" />
                  فتح
                </Button>
                <Button
                  type="button"
                  size="lg"
                  variant="ghost"
                  onClick={handleGenerate}
                  disabled={isProcessing || images.length === 0}
                  className="h-12 gap-2 text-sm font-semibold text-muted-foreground"
                >
                  {isProcessing ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <RotateCw className="h-4 w-4" />
                  )}
                  إعادة
                </Button>
              </div>

              {/* Privacy reminder */}
              <div className="flex items-center justify-center gap-1.5 bg-emerald-100/40 px-4 py-2 text-[11px] text-emerald-800/70 dark:bg-emerald-900/20 dark:text-emerald-200/60">
                <Lock className="h-3 w-3" />
                ملف PDF لم يغادر جهازك إطلاقاً — حمّله الآن أو شاركه مباشرة
              </div>
            </CardContent>
          </Card>
        )}

        {/* Feature chips */}
        <div className="mt-2 flex flex-wrap gap-2">
          <Badge variant="outline" className="gap-1 py-1 pl-2.5">
            <Lock className="h-3 w-3" />
            بدون رفع
          </Badge>
          <Badge variant="outline" className="gap-1 py-1 pl-2.5">
            <Smartphone className="h-3 w-3" />
            يعمل بدون إنترنت
          </Badge>
          <Badge variant="outline" className="gap-1 py-1 pl-2.5">
            <Layers className="h-3 w-3" />
            صفحات متعددة
          </Badge>
          <Badge variant="outline" className="gap-1 py-1 pl-2.5">
            <RotateCw className="h-3 w-3" />
            تدوير وتدرية رمادية
          </Badge>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t bg-background/80 py-4">
        <div className="mx-auto flex w-full max-w-3xl flex-col items-center gap-1 px-4 text-center">
          <p className="text-[11px] text-muted-foreground">
            صُمم للهواتف • يعمل بالكامل داخل المتصفح • بلا تتبّع
          </p>
          <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
            <Github className="h-3 w-3" />
            مبني على Next.js + pdf-lib
          </div>
        </div>
      </footer>

      {/* Preview modal */}
      {previewItem && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
          onClick={() => setPreviewItem(null)}
        >
          <div
            className="relative flex max-h-full max-w-2xl flex-col gap-3"
            onClick={(e) => e.stopPropagation()}
          >
            <Button
              type="button"
              size="icon"
              variant="secondary"
              className="absolute -top-3 -right-3 z-10 h-9 w-9 rounded-full shadow-lg"
              onClick={() => setPreviewItem(null)}
              aria-label="إغلاق المعاينة"
            >
              <X className="h-4 w-4" />
            </Button>
            <img
              src={previewItem.url}
              alt={previewItem.name}
              className="max-h-[80vh] w-auto rounded-lg object-contain"
            />
            <div className="rounded-lg bg-white/95 p-3 text-center text-sm text-foreground shadow-md dark:bg-zinc-900/95">
              <span className="font-medium">{previewItem.name}</span>
              <span className="text-muted-foreground" dir="ltr">
                {" "}
                — {previewItem.width}×{previewItem.height} •{" "}
                {formatBytes(previewItem.size)}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ──────────────────────────────────────────────────────────────────────────────
// Settings panel
// ──────────────────────────────────────────────────────────────────────────────
function SettingsPanel({
  pageSize,
  setPageSize,
  margin,
  setMargin,
  rotate,
  setRotate,
  grayscale,
  setGrayscale,
  quality,
  setQuality,
  maxDimension,
  setMaxDimension,
}: {
  pageSize: PageSizeKey;
  setPageSize: (v: PageSizeKey) => void;
  margin: number;
  setMargin: (v: number) => void;
  rotate: 0 | 90 | 180 | 270;
  setRotate: (v: 0 | 90 | 180 | 270) => void;
  grayscale: boolean;
  setGrayscale: (v: boolean) => void;
  quality: number;
  setQuality: (v: number) => void;
  maxDimension: number;
  setMaxDimension: (v: number) => void;
}) {
  return (
    <div className="flex flex-col gap-5 px-1 pt-2">
      <div className="flex flex-col gap-1.5">
        <Label className="text-sm font-medium">حجم الصفحة</Label>
        <Select
          value={pageSize}
          onValueChange={(v) => setPageSize(v as PageSizeKey)}
        >
          <SelectTrigger className="w-full">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {PAGE_SIZES.map((s) => (
              <SelectItem key={s.key} value={s.key}>
                <div className="flex flex-col">
                  <span>{s.label}</span>
                  <span className="text-[10px] text-muted-foreground">
                    {s.description}
                  </span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <Label className="text-sm font-medium">الهامش (نقطة)</Label>
          <span className="text-xs text-muted-foreground" dir="ltr">
            {margin}px
          </span>
        </div>
        <Slider
          min={0}
          max={80}
          step={2}
          value={[margin]}
          onValueChange={(v) => setMargin(v[0])}
        />
      </div>

      <div className="flex flex-col gap-1.5">
        <Label className="text-sm font-medium">تدوير كل الصفحات</Label>
        <Select
          value={String(rotate)}
          onValueChange={(v) =>
            setRotate(Number(v) as 0 | 90 | 180 | 270)
          }
        >
          <SelectTrigger className="w-full">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="0">0° — بدون تدوير</SelectItem>
            <SelectItem value="90">90° — يمين</SelectItem>
            <SelectItem value="180">180° — مقلوب</SelectItem>
            <SelectItem value="270">270° — يسار</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Separator />

      <div className="flex items-center justify-between gap-3">
        <div>
          <Label className="text-sm font-medium">تدرية رمادية</Label>
          <p className="text-[11px] text-muted-foreground">
            تحويل الصور إلى أبيض وأسود
          </p>
        </div>
        <Switch checked={grayscale} onCheckedChange={setGrayscale} />
      </div>

      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <Label className="text-sm font-medium">جودة الصورة</Label>
          <span className="text-xs text-muted-foreground" dir="ltr">
            {Math.round(quality * 100)}%
          </span>
        </div>
        <Slider
          min={0.4}
          max={1}
          step={0.05}
          value={[quality]}
          onValueChange={(v) => setQuality(v[0])}
        />
        <p className="text-[11px] text-muted-foreground">
          جودة أعلى = حجم ملف أكبر. الافتراضي 85% توازن جيد.
        </p>
      </div>

      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <Label className="text-sm font-medium">أقصى أبعاد للصورة</Label>
          <span className="text-xs text-muted-foreground" dir="ltr">
            {maxDimension}px
          </span>
        </div>
        <Slider
          min={800}
          max={4000}
          step={100}
          value={[maxDimension]}
          onValueChange={(v) => setMaxDimension(v[0])}
        />
        <p className="text-[11px] text-muted-foreground">
          تُصغَّر الصور الكبيرة تلقائياً لتقليل حجم PDF. الافتراضي 2000px.
        </p>
      </div>
    </div>
  );
}
