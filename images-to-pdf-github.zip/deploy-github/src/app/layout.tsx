import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

export const metadata: Metadata = {
  title: "صور إلى PDF — محوّل آمن",
  description:
    "حوّل صورك إلى ملف PDF مباشرة على هاتفك. كل المعالجة تتم داخل المتصفح، صورك لا تغادر جهازك إطلاقاً.",
  keywords: [
    "صور إلى PDF",
    "تحويل PDF",
    "آمن",
    "خصوصية",
    "هاتف",
    "بدون رفع",
  ],
  authors: [{ name: "Z.ai" }],
  openGraph: {
    title: "صور إلى PDF — محوّل آمن",
    description: "حوّل صورك إلى PDF مباشرة على جهازك بدون رفع لأي خادم.",
    siteName: "صور إلى PDF",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "صور إلى PDF — محوّل آمن",
    description: "حوّل صورك إلى PDF مباشرة على جهازك بدون رفع لأي خادم.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body className="antialiased bg-background text-foreground">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
