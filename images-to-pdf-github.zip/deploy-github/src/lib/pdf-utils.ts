"use client";

import { PDFDocument, degrees, rgb, StandardFonts } from "pdf-lib";

export type PageSizeKey = "fit" | "a4" | "letter";

export interface PageSizeInfo {
  key: PageSizeKey;
  label: string;
  description: string;
  // dimensions in PDF points (1pt = 1/72 inch). A4 = 595.28 x 841.89
  width?: number;
  height?: number;
}

export const PAGE_SIZES: PageSizeInfo[] = [
  {
    key: "fit",
    label: "مطابقة للصورة",
    description: "حجم الصفحة بنفس مقاس الصورة الأصلية",
  },
  {
    key: "a4",
    label: "A4",
    description: "ورقة A4 عمودية (210 × 297 ملم)",
    width: 595.28,
    height: 841.89,
  },
  {
    key: "letter",
    label: "Letter",
    description: "ورقة US Letter عمودية (8.5 × 11 إنش)",
    width: 612,
    height: 792,
  },
];

export interface BuildPdfOptions {
  pageSize: PageSizeKey;
  margin: number; // in points
  rotate: 0 | 90 | 180 | 270;
  grayscale: boolean;
  quality: number; // 0.5 - 1.0 (jpeg quality when re-encoding)
  maxDimension: number; // max width/height in px to downscale very large images
  includeMetadata?: boolean;
  title?: string;
  author?: string;
}

export interface ImageItem {
  id: string;
  file: File;
  url: string; // object URL for preview
  name: string;
  size: number;
  width: number;
  height: number;
  type: string;
}

/**
 * Load an image File, return decoded bytes + natural dimensions + an object URL.
 */
export async function loadImageItem(file: File): Promise<ImageItem> {
  const url = URL.createObjectURL(file);
  try {
    const dims = await getImageDimensions(url);
    return {
      id: `${file.name}-${file.size}-${Math.random().toString(36).slice(2, 9)}`,
      file,
      url,
      name: file.name,
      size: file.size,
      width: dims.width,
      height: dims.height,
      type: file.type,
    };
  } catch (e) {
    URL.revokeObjectURL(url);
    throw e;
  }
}

function getImageDimensions(
  url: string,
): Promise<{ width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve({ width: img.naturalWidth, height: img.naturalHeight });
    img.onerror = () => reject(new Error("تعذّر قراءة الصورة"));
    img.src = url;
  });
}

/**
 * Re-encode the image into a JPEG (or keep PNG for transparency) with optional
 * grayscale + downscale. Returns Uint8Array suitable for pdf-lib embedding.
 */
async function prepareImageBytes(
  item: ImageItem,
  opts: BuildPdfOptions,
): Promise<{ bytes: Uint8Array; format: "jpg" | "png"; width: number; height: number }> {
  const { grayscale, maxDimension, quality } = opts;

  // Downscale if needed
  let targetW = item.width;
  let targetH = item.height;
  const longest = Math.max(targetW, targetH);
  if (longest > maxDimension) {
    const scale = maxDimension / longest;
    targetW = Math.max(1, Math.round(targetW * scale));
    targetH = Math.max(1, Math.round(targetH * scale));
  }

  // Only re-encode if we need to downscale or grayscale; otherwise keep original bytes.
  if (longest <= maxDimension && !grayscale) {
    const raw = new Uint8Array(await item.file.arrayBuffer());
    const format: "jpg" | "png" =
      item.type === "image/png" ? "png" : "jpg";
    return { bytes: raw, format, width: item.width, height: item.height };
  }

  // Draw to canvas to re-encode
  const canvas = document.createElement("canvas");
  canvas.width = targetW;
  canvas.height = targetH;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("تعذّر تهيئة canvas");

  // For grayscale: fill white background (in case of transparent PNG -> avoid black),
  // then apply grayscale filter.
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, targetW, targetH);

  const img = new Image();
  img.src = item.url;
  await new Promise<void>((res, rej) => {
    img.onload = () => res();
    img.onerror = () => rej(new Error("تعذّر تحميل الصورة"));
  });

  if (grayscale) {
    ctx.filter = "grayscale(100%)";
  }
  ctx.drawImage(img, 0, 0, targetW, targetH);

  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, "image/jpeg", quality),
  );
  if (!blob) throw new Error("تعذّر إعادة ترميز الصورة");
  const bytes = new Uint8Array(await blob.arrayBuffer());
  return { bytes, format: "jpg", width: targetW, height: targetH };
}

/**
 * Build a PDF from the given images entirely in the browser.
 * Returns the PDF as a Uint8Array.
 */
export async function buildPdf(
  images: ImageItem[],
  opts: BuildPdfOptions,
): Promise<Uint8Array> {
  if (images.length === 0) throw new Error("لا توجد صور لتحويلها");

  const pdfDoc = await PDFDocument.create();

  if (opts.includeMetadata !== false) {
    pdfDoc.setTitle(opts.title || "صور إلى PDF");
    pdfDoc.setAuthor(opts.author || "صور إلى PDF");
    pdfDoc.setCreator("صور إلى PDF — محوّل آمن");
    pdfDoc.setProducer("pdf-lib (معالجة محلية في المتصفح)");
    pdfDoc.setSubject("مستند تم إنشاؤه محلياً بدون رفع لأي خادم");
  }

  const helvetica = await pdfDoc.embedFont(StandardFonts.Helvetica);

  for (let i = 0; i < images.length; i++) {
    const item = images[i];
    const { bytes, format, width: natW, height: natH } = await prepareImageBytes(
      item,
      opts,
    );

    let embedded;
    if (format === "png") {
      embedded = await pdfDoc.embedPng(bytes);
    } else {
      embedded = await pdfDoc.embedJpg(bytes);
    }

    // Apply rotation
    const rotation = ((opts.rotate % 360) + 360) % 360;
    const rotatedW =
      rotation === 90 || rotation === 270 ? natH : natW;
    const rotatedH =
      rotation === 90 || rotation === 270 ? natW : natH;

    let pageW: number;
    let pageH: number;

    const sizeInfo = PAGE_SIZES.find((s) => s.key === opts.pageSize);
    if (opts.pageSize === "fit") {
      // page matches the (rotated) image, plus margin * 2
      pageW = rotatedW + opts.margin * 2;
      pageH = rotatedH + opts.margin * 2;
    } else {
      pageW = sizeInfo?.width ?? 595.28;
      pageH = sizeInfo?.height ?? 841.89;
    }

    const page = pdfDoc.addPage([pageW, pageH]);

    // Compute draw dimensions to fit within (pageW - margin*2) x (pageH - margin*2)
    const availW = Math.max(1, pageW - opts.margin * 2);
    const availH = Math.max(1, pageH - opts.margin * 2);

    let drawW = rotatedW;
    let drawH = rotatedH;
    const scale = Math.min(availW / drawW, availH / drawH, 1);
    drawW = drawW * scale;
    drawH = drawH * scale;

    // Center horizontally + vertically (with a small footer offset)
    const footerOffset = 14;
    const x = (pageW - drawW) / 2;
    const y = (pageH - drawH) / 2 + (opts.includeMetadata !== false ? footerOffset / 2 : 0);

    page.drawImage(embedded, {
      x,
      y,
      width: drawW,
      height: drawH,
      rotate: degrees(rotation),
      xSkew: degrees(0),
      ySkew: degrees(0),
    });

    // Tiny footer (page index) — drawn with safe font; no Arabic chars to avoid font issues.
    if (opts.includeMetadata !== false) {
      const footer = `Page ${i + 1} / ${images.length}  •  Local-only`;
      const fontSize = 7;
      const textW = helvetica.widthOfTextAtSize(footer, fontSize);
      page.drawText(footer, {
        x: (pageW - textW) / 2,
        y: 6,
        size: fontSize,
        font: helvetica,
        color: rgb(0.55, 0.55, 0.55),
      });
    }
  }

  return pdfDoc.save();
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

export function triggerDownload(bytes: Uint8Array, filename: string) {
  const blob = new Blob([bytes as BlobPart], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  // Revoke a bit later so download has time to start
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
